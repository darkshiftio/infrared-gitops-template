# Hello Bedrock

A one-page static site, `index.html` at the root, nothing to build. The starter of infrared-gitops-template's
`scripts/bedrock-proof.sh`, which proves that an org's agent steps run on Amazon Bedrock. Safe to delete.
